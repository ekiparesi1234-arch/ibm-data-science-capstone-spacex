# IBM Applied Data Science Capstone: SpaceX Falcon 9 First Stage Landing Prediction

Capstone project for the IBM Applied Data Science course. The goal is to predict
whether the Falcon 9 first stage will land successfully, since a reusable first
stage is what lets SpaceX offer launches at a much lower cost.

## Repository structure

| Folder | Contents |
|---|---|
| `notebooks/` | Jupyter notebooks for each stage of the project |
| `dashboard/` | Plotly Dash app (`spacex_dash_app.py`) |
| `data/` | Datasets exported by the notebooks (CSV) |
| `images/` | Screenshots of the Folium map and the Dash dashboard |
| `presentation/` | Final report (`Data Science Capstone Project Report.pdf`) |

## Notebooks (add the files here)

1. Data collection with the SpaceX REST API
2. Data collection with web scraping (Wikipedia, BeautifulSoup)
3. Data wrangling
4. EDA with SQL
5. EDA with data visualization
6. Interactive map with Folium
7. Machine learning prediction

## Methodology (short)

- Collect launch data from the SpaceX API and Wikipedia.
- Clean the data, handle missing values, and create the landing `Class` label.
- Explore the data with SQL and visualizations.
- Build an interactive Folium map and a Plotly Dash dashboard.
- Train and compare classification models (logistic regression, SVM,
  decision tree, KNN) with GridSearchCV.

## How to run

```bash
pip install -r requirements.txt
python dashboard/spacex_dash_app.py
```

## Author

(Your name)
